1. Download the python automation code from the git repo
2. Use python editor like pycharm and load the project
3. Ensure the Booking_Catlogue_config is having following configuration:
Script path: \LenusHealthAPIProj\venv\Lib\site-packages\behave\__main__.py 
Working directory: \PycharmProjects\LenusHealthAPIProj
4. Under Setting, ensure Python Interpreter having following packages installed
   a. behave
   b. jsonpath
   c. requests
5. Run the automation from feature module [ ALl feature will be executed ]
6. Ensured no print statement in the code