import requests
from behave import Step

api_endpoints = {}
request_headers = {}
response_codes = {}
response_texts = {}
request_bodies = {}
api_url = None


# START POST Scenario
@Step("I Set POST posts api endpoint")
def post_api_endpoint_initialisation(context):
    api_endpoints['POST_URL'] = context.base_url + context.create_booking_url


@Step("Set request Body")
def create_booking_catalogue_payload_setup(context):
    request_bodies['POST'] = {"title": "Journey to the Center of the Earth", "author": "Jules Verne", "price": 10.99}


@Step("Send a POST HTTP request")
def create_booking_catalogue_response_extraction(context):
    # sending get request and saving response as response object
    response = requests.post(url=api_endpoints['POST_URL'], json=request_bodies['POST'], headers=request_headers)

    # extracting response text
    response_texts['POST'] = response.text
    # extracting response status_code
    statuscode = response.status_code
    response_codes['POST'] = statuscode


@Step("Set request Body with blank title")
def create_booking_catalogue_payload_setup(context):
    request_bodies['POST'] = {"title": "", "author": "Jules Verne", "price": 10.99}


@Step("I receive valid POST HTTP response code '{respcode}'")
def validate_response_code(context, respcode):
    assert response_codes['POST'] == int(respcode)

# END Create Booking Scenario
