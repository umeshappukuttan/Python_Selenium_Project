import requests
from behave import Step
import json


api_endpoints = {}
request_headers = {}
response_codes = {}
response_texts = {}
request_bodies = {}


@Step("I Set GET api endpoint '{id}'")
def step_impl(context, id):
    api_endpoints['GET_URL'] = context.base_url + context.create_booking_url + "/" + str(id)


@Step("Send GET HTTP request")
def step_impl(context):
    # sending get request and saving response as response object
    response = requests.get(url=api_endpoints['GET_URL'], headers=request_headers)
    # extracting response text
    response_texts['GET']=response.text
    # extracting response status_code
    statuscode = response.status_code
    response_codes['GET'] = statuscode


@Step("I receive valid GET HTTP response code '{respcode}'")
def validate_response_code(context, respcode):
    assert response_codes['GET'] == int(respcode)

# END GET Scenario
