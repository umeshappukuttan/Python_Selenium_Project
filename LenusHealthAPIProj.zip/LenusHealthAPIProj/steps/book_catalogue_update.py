import requests
from behave import Step
import json


api_endpoints = {}
request_headers = {}
response_codes = {}
response_texts = {}
request_bodies = {}


#START PUT/UPDATE


@Step("I Set PUT api endpoint for '{id}'")
def step_impl(context,id):
    api_endpoints['PUT_URL'] = context.base_url + context.create_booking_url + "/" + id


@Step("I Set Update request Body")
def step_impl(context):
    request_bodies['PUT']={"title": "updated title", "author": "updated author", "price": 777.77}


@Step("Send PUT HTTP request")
def step_impl(context):
    # sending get request and saving response as response object
    response = requests.put(url=api_endpoints['PUT_URL'], json=request_bodies['PUT'], headers=request_headers)
    # extracting response text
    response_texts['PUT'] = response.text
    # extracting response status_code
    statuscode = response.status_code
    response_codes['PUT'] = statuscode


@Step("I receive valid PUT HTTP response code '{respcode}'")
def validate_response_code(context, respcode):
    assert response_codes['PUT'] == int(respcode)

#END PUT/UPDATE