import requests
from behave import Step
import json


api_endpoints = {}
request_headers = {}
response_codes = {}
response_texts = {}
request_bodies = {}


@Step("I Set GET api endpoint for sort by ID")
def step_impl(context):
    api_endpoints['GET_URL'] = context.base_url + context.sort_by_id_url


@Step("I Set GET api endpoint for sort by title")
def step_impl(context):
    api_endpoints['GET_URL'] = context.base_url + context.sort_by_title_url


@Step("I Set GET api endpoint for sort by author")
def step_impl(context):
    api_endpoints['GET_URL'] = context.base_url + context.sort_by_author_url


@Step("I receive valid GET HTTP response code '{respcode}' for sort")
def validate_response_code(context, respcode):
    assert response_codes['GET'] == int(respcode)


@Step("Send GET HTTP request for sort")
def step_impl(context):
    # sending get request and saving response as response object
    response = requests.get(url=api_endpoints['GET_URL'], headers=request_headers)
    # extracting response text
    response_texts['GET']=response.text
    # extracting response status_code
    statuscode = response.status_code
    response_codes['GET'] = statuscode

# END GET Scenario
