from behave import Step


request_headers = {}
response_codes = {}
response_texts = {}
apimethod = {}


@Step("I set sample REST API url")
def create_booking_api_endpoint(context):
    global api_url
    api_url = context.base_url


@Step("I Set HEADER param request content type as '{header_content_type}'")
def post_api_endpoint_header_content_type(context, header_content_type):
    request_headers['Content-Type'] = header_content_type


@Step("Response BODY '{request_name}' is non-empty")
def verify_response_is_not_empty(context, request_name):
    assert response_texts is not None


@Step("Response BODY {'GET'} is non-empty")
def step_impl(context,request_name):
    assert response_texts[request_name] is not None
